// Get references to the input, button, result display, & animation container elements
const numberInput = document.getElementById("number-input");
const convertBtn = document.getElementById("convert-btn");
const result = document.getElementById("result");
const animationContainer = document.getElementById("animation-container");

// Recursive function to convert a decimal number to binary
const decimalToBinary = (input) => {
  // Base cases: return "0" or "1" directly if input is 0 or 1
  if (input === 0 || input === 1) {
    return String(input);
  } else {
    // Recursive step: divide the input by 2 & get the remainder to build the binary string
    return decimalToBinary(Math.floor(input / 2)) + (input % 2);
  }
};

// Generate the animation steps to visualize the binary conversion process
const generateAnimationData = (num) => {
  let animationData = [];
  let tempNum = num;
  let delay = 0;

  // Loop until until the base case reached
  while (tempNum > 1) {
    let binaryDigit = tempNum % 2;  // Get the binary digit (remainder)
    let nextNum = Math.floor(tempNum / 2);  // Calculate the next number in the sequence

    // Add data for the current animation step
    animationData.push({
      inputVal: tempNum,
      msg: `decimalToBinary(${tempNum}) returns "${nextNum}" + ${binaryDigit} (${tempNum} % 2) and passes it down.`,
      addElDelay: delay * 1000,  // Delay for adding element
      showMsgDelay: (delay + 1) * 1000,  // Delay for displaying the message
      removeElDelay: (delay + 2) * 1000,  // Delay for removing the element
    });
    
    tempNum = nextNum;  // Update tempNum for the next iteration
    delay += 2;  // Increment delay for the next steps
  }

  // Add the final base case step
  animationData.push({
    inputVal: tempNum,
    msg: `decimalToBinary(${tempNum}) returns "${tempNum}" (base case) and starts resolving up the stack.`,
    addElDelay: delay * 1000,
    showMsgDelay: (delay + 1) * 1000,
    removeElDelay: (delay + 2) * 1000,
  });

  return animationData.reverse();  // Reverse the array to match the animation order
};

// Display the binary conversion animation
const showAnimation = (num) => {
  const animationData = generateAnimationData(num);
  result.textContent = decimalToBinary(num);  // Show the final binary result

  // Iterate over each animation step
  animationData.forEach((obj) => {
    // Add each frame to the animation container
    setTimeout(() => {
      animationContainer.innerHTML += `
        <p id="${obj.inputVal}" class="animation-frame">
          decimalToBinary(${obj.inputVal})
        </p>
      `;
    }, obj.addElDelay);

    // Display the message with delay
    setTimeout(() => {
      document.getElementById(obj.inputVal).textContent = obj.msg;
    }, obj.showMsgDelay);

    // Remove the frame after displaying the message
    setTimeout(() => {
      document.getElementById(obj.inputVal).remove();
    }, obj.removeElDelay);
  });
};

// Validate user input & trigger the animation if valid
const checkUserInput = () => {
  const inputInt = parseInt(numberInput.value);

  // Check if input is a valid non-negative integer
  if (!numberInput.value || isNaN(inputInt) || inputInt < 0) {
    alert("Please provide a decimal number greater than or equal to 0");
    return;
  }

  showAnimation(inputInt);  // Start animation for the valid input
  numberInput.value = "";  // Clear the input field after processing
};

// Add event listeners for button click and Enter key
convertBtn.addEventListener("click", checkUserInput);

numberInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    checkUserInput();
  }
});
