# Function to return the square of a number (used in non-pointer-like example)
def increment(num: int) -> int:
    return num ** 2

# Initial integer value
x = -5

# Updating x with the squared value
x = increment(x)

# Printing the updated integer value (25)
print(x)

# Function to square the first element of a list (used in pointer-like manner as an array in C++)
def increment(num_list: list[int]) -> None:
    if not isinstance(num_list[0], int):
        raise TypeError("The first element of the list must be an integer.")
    num_list[0] = num_list[0] ** 2

# Creating a list with a single integer to simulate a pointer to a variable
x = [200]

# Passing the list to the function, which modifies its first element in place
increment(x)

# Printing the modified value in the list (40000), simulating dereferenced pointer behavior
print(x[0])

# Example to trigger the error handling for test case 5
try:
    x = ["Patrick Hill"]  # Non-integer element in list
    increment(x)
except TypeError as e:
    print(e)
